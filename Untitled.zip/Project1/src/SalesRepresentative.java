public class SalesRepresentative extends Employee {
    private int salesMade;

    public SalesRepresentative(String name, int id, double salary, int salesMade) {
        super(name, id, salary, "Sales Representative");
        this.salesMade = salesMade;
    }

    public int getSalesMade() {
        return salesMade;
    }

    public void setSalesMade(int salesMade) throws IllegalArgumentException {
        if (salesMade < 0) {
            throw new IllegalArgumentException("Sales made cannot be negative.");
        }
        this.salesMade = salesMade;
    }

    public void printSalesReport() {
        System.out.println("Name: " + getName());
        System.out.println("ID: " + getID());
        System.out.println("Salary: $" + getSalary());
        System.out.println("Job Title: " + getJobTitle());
        System.out.println("Sales Made: " + salesMade);
    }
}
