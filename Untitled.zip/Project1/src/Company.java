public class Company {
    private String name;
    private Department[] departments;
    private int numDepartments;

    public Company(String name) {
        this.name = name;
        departments = new Department[10]; // default capacity of 10
        numDepartments = 0;
    }

    // Add a department to the company
    public void addDepartment(Department dept) {
        try {
            // If the array is full, resize it by doubling its capacity
            if (numDepartments == departments.length) {
                Department[] newDepartments = new Department[departments.length * 2];
                System.arraycopy(departments, 0, newDepartments, 0, departments.length);
                departments = newDepartments;
            }

            departments[numDepartments++] = dept;
        } catch (Exception e) {
            System.out.println("An error occurred while adding a department: " + e.getMessage());
        }
    }

    // Get a department by its name
    public Department getDepartment(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Department name cannot be null");
        }

        for (Department department : departments) {
            if (department.getName().equals(name)) {
                return department;
            }
        }

        throw new IllegalArgumentException("Department with name " + name + " does not exist");
    }

    // Get the total number of employees in the company
    public int getTotalEmployees() {
        int count = 0;

        for (int i = 0; i < numDepartments; i++) {
            count += departments[i].getTotalEmployees();
        }

        return count;
    }

    // Print a report of all employees in the company
    public void printEmployeeReport() {
        System.out.println("Employee Report for " + name);

        for (int i = 0; i < numDepartments; i++) {
            System.out.println("Department: " + departments[i].getName());
            departments[i].printEmployeeReport();
        }
    }

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Department[] getDepartments()
	{
		return departments;
	}

	public void setDepartments(Department[] departments)
	{
		this.departments = departments;
	}

	public int getNumDepartments()
	{
		return numDepartments;
	}

	public void setNumDepartments(int numDepartments)
	{
		this.numDepartments = numDepartments;
	}

    
}
