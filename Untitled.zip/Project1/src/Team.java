public class Team {
    private String name;
    private Employee[] employees;
    private int numEmployees;

    public Team(String name) {
        this.name = name;
        employees = new Employee[10]; // default capacity of 10
        numEmployees = 0;
    }

    // Add an employee to the team
    public void addEmployee(Employee employee) throws TeamFullException {
        if (numEmployees == employees.length) {
            throw new TeamFullException("Cannot add employee to team, team is full.");
        }
        employees[numEmployees++] = employee;
    }

    // Get an employee by their name
    public Employee getEmployee(String name) throws EmployeeNotFoundException {
        for (int i = 0; i < numEmployees; i++) {
            if (employees[i].getName().equals(name)) {
                return employees[i];
            }
        }

        throw new EmployeeNotFoundException("Employee with name " + name + " not found in team.");
    }

    // Get the total number of employees in the team
    public int getTotalEmployees() {
        return numEmployees;
    }

    // Print a report of all employees in the team
    public void printEmployeeReport() {
        for (int i = 0; i < numEmployees; i++) {
            System.out.println(" - " + employees[i].getName() + " (" + employees[i].getJobTitle() + ")");
        }
    }

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Employee[] getEmployees()
	{
		return employees;
	}

	public void setEmployees(Employee[] employees)
	{
		this.employees = employees;
	}

	public int getNumEmployees()
	{
		return numEmployees;
	}

	public void setNumEmployees(int numEmployees)
	{
		this.numEmployees = numEmployees;
	}
}
