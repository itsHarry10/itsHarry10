public class Employee {
    private String name;
    private int id;
    private double salary;
    private String jobTitle;

    public Employee(String name, int id, double salary, String jobTitle) {
    	if (name == null || name.isEmpty())
    	{
            throw new IllegalArgumentException("Employee name cannot be null or empty.");
        }
        if (jobTitle == null || jobTitle.isEmpty())
        {
            throw new IllegalArgumentException("Employee job title cannot be null or empty.");
        }
        this.name = name;
        this.id = id;
        this.salary = salary;
        this.jobTitle = jobTitle;
    }

    // Get the name of the employee
    public String getName() {
        return name;
    }

    // Get the ID of the employee
    public int getID() {
        return id;
    }

    // Get the salary of the employee
    public double getSalary() {
        return salary;
    }

    public void setName(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Employee name cannot be null or empty.");
        }
        
        this.name = name;
    }

    public void setJobTitle(String jobTitle) {
        if (jobTitle == null || jobTitle.isEmpty()) {
            throw new IllegalArgumentException("Employee job title cannot be null or empty.");
        }
        
        this.jobTitle = jobTitle;
    }

    // Get the job title of the employee
    public String getJobTitle() {
        return jobTitle;
    }

    

    // Print a report of the employee's details
    public void printEmployeeReport() {
        System.out.println("Name: " + name);
        System.out.println("ID: " + id);
        System.out.println("Salary: $" + salary);
        System.out.println("Job Title: " + jobTitle);
    }

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}
    
    
}
