public class HRManager extends Employee {
    private int employeesManaged;

    public HRManager(String name, int id, double salary, int employeesManaged) {
        super(name, id, salary, "HR Manager");
        this.employeesManaged = employeesManaged;
    }

    public int getEmployeesManaged() {
        return employeesManaged;
    }

    public void setEmployeesManaged(int employeesManaged) {
        this.employeesManaged = employeesManaged;
    }

    public void printHRReport() throws EmployeeNotFoundException {
        if (employeesManaged == 0) {
            throw new EmployeeNotFoundException("There are no employees managed by this HR Manager.");
        }
        System.out.println("Name: " + getName());
        System.out.println("ID: " + getID());
        System.out.println("Salary: $" + getSalary());
        System.out.println("Job Title: " + getJobTitle());
        System.out.println("Employees Managed: " + employeesManaged);
    }
}
