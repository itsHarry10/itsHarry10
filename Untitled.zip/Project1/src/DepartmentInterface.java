public interface DepartmentInterface
{
    public void addTeam(Team team) throws Exception;
    public Team[] getTeams();
}
