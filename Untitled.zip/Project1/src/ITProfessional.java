public class ITProfessional extends Employee {
    private String technology;

    public ITProfessional(String name, int id, double salary, String technology) {
        super(name, id, salary, "IT Professional");
        this.technology = technology;
    }

    public String getTechnology() {
        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology;
    }

    @Override
    public String toString() {
        return super.toString() + ", Technology: " + technology;
    }

    // IT Professional specific method
    public void fixComputer() {
        System.out.println("IT Professional " + getName() + " is fixing a computer.");
    }
}