public class Marketer extends Employee {
    private String campaign;

    public Marketer(String name, int id, double salary, String campaign) {
        super(name, id, salary, "Marketer");
        this.campaign = campaign;
    }

    public String getCampaign() {
        return campaign;
    }

    public void setCampaign(String campaign) {
        this.campaign = campaign;
    }

    public void printCampaignReport() throws CampaignNotFoundException {
        if (campaign == null || campaign.isEmpty()) {
            throw new CampaignNotFoundException("Campaign not found");
        }

        System.out.println("Name: " + getName());
        System.out.println("ID: " + getID());
        System.out.println("Salary: $" + getSalary());
        System.out.println("Job Title: " + getJobTitle());
        System.out.println("Campaign: " + campaign);
    }
}
