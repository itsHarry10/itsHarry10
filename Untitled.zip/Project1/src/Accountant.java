public class Accountant extends Employee {
    private String financialReport;

    public Accountant(String name, int id, double salary, String financialReport) {
        super(name, id, salary, "Accountant");
        this.financialReport = financialReport;
    }

    public String getFinancialReport() {
        return financialReport;
    }

    public void setFinancialReport(String financialReport) {
        this.financialReport = financialReport;
    }

    public void printFinancialReport() throws FinancialReportNotFoundException {
        if (financialReport == null) {
            throw new FinancialReportNotFoundException("Financial report not found for " + getName());
        }

        System.out.println("Name: " + getName());
        System.out.println("ID: " + getID());
        System.out.println("Salary: $" + getSalary());
        System.out.println("Job Title: " + getJobTitle());
        System.out.println("Financial Report: " + financialReport);
    }
}
