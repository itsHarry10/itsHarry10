public class CustomerServiceRepresentative extends Employee {
    private int customersServed;

    public CustomerServiceRepresentative(String name, int id, double salary, int customersServed) {
        super(name, id, salary, "Customer Service Representative");
        this.customersServed = customersServed;
    }

    public int getCustomersServed() {
        return customersServed;
    }

    public void setCustomersServed(int customersServed) {
        this.customersServed = customersServed;
    }

    @Override
    public String toString() {
        return super.toString() + ", Customers Served: " + customersServed;
    }

    // Customer Service Representative specific method
    public void takeCall() {
        System.out.println("Customer Service Representative " + getName() + " is taking a call.");
    }
}