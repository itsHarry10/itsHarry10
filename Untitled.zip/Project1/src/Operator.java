public class Operator extends Employee {
    private String machineType;

    public Operator(String name, int id, double salary, String machineType) {
        super(name, id, salary, "Operator");
        this.machineType = machineType;
    }

    public String getMachineType() {
        return machineType;
    }

    public void setMachineType(String machineType) {
        this.machineType = machineType;
    }

    public void printMachineType() {
        System.out.println("Machine Type: " + machineType);
    }
}
