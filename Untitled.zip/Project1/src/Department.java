public class Department implements DepartmentInterface
{
	private String name;
	private Team[] teams;
	private int numTeams;
	
	
	public Department(String name)
	{
		this.name = name;
		teams = new Team[10]; // default capacity of 10
		numTeams = 0;
	}

	// Add a team to the department
	public void addTeam(Team team) throws Exception {
		// If the array is full, resize it by doubling its capacity
		if (numTeams == teams.length) {
			Team[] newTeams = new Team[teams.length * 2];
			System.arraycopy(teams, 0, newTeams, 0, teams.length);
			teams = newTeams;
		}

		if (team == null) {
			throw new Exception("Cannot add null team to department");
		}

		teams[numTeams++] = team;
	}

	// Get a team by its name
	public Team getTeam(String name) {
		for (int i = 0; i < numTeams; i++) {
			if (teams[i].getName().equals(name)) {
				return teams[i];
			}
		}

		return null;
	}

	// Get the total number of employees in the department
	public int getTotalEmployees() {
		int count = 0;

		for (int i = 0; i < numTeams; i++) {
			count += teams[i].getTotalEmployees();
		}

		return count;
	}

	// Print a report of all employees in the department
	public void printEmployeeReport() {
		System.out.println("Employee Report for " + name);

		for (int i = 0; i < numTeams; i++) {
			System.out.println("Team: " + teams[i].getName());
			teams[i].printEmployeeReport();
		}
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Team[] getTeams()
	{
		return teams;
	}

	public void setTeams(Team[] teams)
	{
		this.teams = teams;
	}

	public int getNumTeams()
	{
		return numTeams;
	}

	public void setNumTeams(int numTeams)
	{
		this.numTeams = numTeams;
	}
}