@SuppressWarnings("serial")
public class CampaignNotFoundException extends Exception {
    public CampaignNotFoundException(String message) {
        super(message);
    }
}
