@SuppressWarnings("serial")
public class TeamFullException extends Exception
{
    public TeamFullException(String message)
    {
        super(message);
    }
}
