@SuppressWarnings("serial")
public class FinancialReportNotFoundException extends Exception
{
    public FinancialReportNotFoundException(String message) {
        super(message);
    }
}
